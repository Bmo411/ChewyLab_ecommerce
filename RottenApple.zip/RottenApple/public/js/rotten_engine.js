"use strict";

const API_URL = 'http://localhost:3000/api/products';
const path = window.location.pathname;
let globalProducts = []; 

document.addEventListener('DOMContentLoaded', () => {
    updateCartBadge(); // Siempre actualizar el contador al cargar

    if (path.includes('shoppingcart.html')) {
        loadShoppingCart();
    } else {
        // Asumimos que es collections o mainpage
        loadCollection();
    }
});

/* =========================================
   1. LÓGICA DE COLECCIONES Y MODAL
   ========================================= */
async function loadCollection() {
    try {
        const response = await fetch(API_URL);
        globalProducts = await response.json(); // Guardamos productos en memoria

        const container = document.querySelector('.products-grid');
        if (!container) return;

        container.innerHTML = ''; 
        
        globalProducts.forEach(product => {
            container.innerHTML += createProductCard(product);
        });

    } catch (error) {
        console.error("Error cargando productos:", error);
    }
}

function createProductCard(product) {
    let badge = '';
    if (product.oldPrice) badge = '<div class="product-badge sale">OFERTA</div>';
    else if (product.isNew) badge = '<div class="product-badge new">NUEVO</div>';

    let priceHtml = `<span class="price">$${product.price}</span>`;
    if (product.oldPrice) {
        priceHtml += `<span class="price-old">$${product.oldPrice}</span>`;
    }

    return `
    <div class="product-card">
        ${badge}
        <div class="product-image-wrapper">
            <img src="${product.image}" alt="${product.title}" class="product-img">
            <div class="product-quick-view">
                <button class="btn-quick-view" 
                        data-toggle="modal" 
                        data-target="#quickViewModal"
                        onclick="openQuickView('${product.uuid}')">
                    Vista Rápida
                </button>
            </div>
        </div>
        <div class="product-info">
            <h3 class="product-title">${product.title}</h3>
            <p class="product-category">${product.category}</p>
            <div class="product-price">${priceHtml}</div>
        </div>
    </div>`;
}

// --- LÓGICA DEL MODAL ---
function openQuickView(productId) {
    // 1. Buscar el producto en los datos que ya descargamos
    const product = globalProducts.find(p => p.uuid === productId);
    if (!product) return;

    // 2. Referencias a los elementos del HTML del modal
    const modalImg = document.getElementById("product-img-modal");
    const modalTitle = document.querySelector(".details-modal h1");
    const modalPrice = document.querySelector(".details-modal h2");
    const modalDesc = document.querySelector(".details-modal p");
    const btnAddToCart = document.querySelector(".details-modal .btn-add-to-cart-modal");

    // 3. Llenar los datos visuales
    modalImg.src = product.image;
    modalTitle.textContent = product.title;
    modalDesc.textContent = product.description;
    
    // Formato de precio (Si hay oferta, mostrar tachado)
    if (product.oldPrice) {
        modalPrice.innerHTML = `<span style="text-decoration: line-through; color: #999; font-size: 0.8em;">$${product.oldPrice}</span> $${product.price}`;
    } else {
        modalPrice.textContent = `$${product.price}`;
    }

    // 4. PREPARAR EL BOTÓN DE "AGREGAR AL CARRITO"
    // Truco: Clonamos el botón para borrar cualquier evento "onclick" anterior 
    // (para que no se agreguen productos de clics pasados)
    const newBtn = btnAddToCart.cloneNode(true);
    btnAddToCart.parentNode.replaceChild(newBtn, btnAddToCart);

    // Asignar el nuevo evento click
    newBtn.onclick = (e) => {
        e.preventDefault(); // Evitar que el formulario recargue la página

        // A. Obtener la talla seleccionada
        // Buscamos el input "radio" que esté marcado (:checked)
        const sizeInput = document.querySelector('input[name="size-modal"]:checked');
        const size = sizeInput ? sizeInput.value : 'M'; // Si no selecciona nada, default 'M'

        // B. Obtener la cantidad
        const qtyInput = document.querySelector('.quantity-select-modal input');
        const qty = qtyInput ? qtyInput.value : 1;

        // C. Guardar en carrito
        addToCart(product.uuid, qty, size);

        // D. Cerrar modal (usando jQuery de Bootstrap)
        $('#quickViewModal').modal('hide');
    };
}

/* =========================================
   2. LÓGICA DE CARRITO (LOCALSTORAGE)
   ========================================= */
function addToCart(productId, quantity, size) {
    let cart = JSON.parse(localStorage.getItem('rottenCart')) || [];
    
    // Verificar si ya existe exactamente el mismo producto + talla
    const existingItem = cart.find(item => item.id === productId && item.size === size);

    if (existingItem) {
        existingItem.quantity = parseInt(existingItem.quantity) + parseInt(quantity);
    } else {
        cart.push({
            id: productId,
            quantity: parseInt(quantity),
            size: size
        });
    }

    localStorage.setItem('rottenCart', JSON.stringify(cart));
    updateCartBadge();
    
    // Alerta visual
    alert("¡Producto añadido al carrito!");
}

function updateCartBadge() {
    const cart = JSON.parse(localStorage.getItem('rottenCart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + parseInt(item.quantity), 0);
    
    // Actualizar todos los badges que existan en la página (navbar)
    const badges = document.querySelectorAll('.cart-badge');
    badges.forEach(b => b.textContent = totalItems);
    
    // Si usas el icono fontawesome y no tienes el span .cart-badge creado:
    const iconContainer = document.querySelector('.fa-shopping-cart');
    if (iconContainer && badges.length === 0 && totalItems > 0) {
        // Crear badge si no existe
        const span = document.createElement('span');
        span.className = 'cart-badge';
        span.style.cssText = 'position: absolute; top: -8px; right: -10px; background: #5B3A7B; color: white; border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold;';
        span.textContent = totalItems;
        iconContainer.parentElement.style.position = 'relative';
        iconContainer.parentElement.appendChild(span);
    }
}

// Eliminar item (usado en shoppingcart.html)
function removeFromCart(productId, size) {
    let cart = JSON.parse(localStorage.getItem('rottenCart')) || [];
    cart = cart.filter(item => !(item.id === productId && item.size === size));
    localStorage.setItem('rottenCart', JSON.stringify(cart));
    
    if (path.includes('shoppingcart.html')) loadShoppingCart();
    updateCartBadge();
}

// Actualizar cantidad (usado en shoppingcart.html)
function updateQuantity(productId, size, newQty) {
    if (newQty < 1) return;
    let cart = JSON.parse(localStorage.getItem('rottenCart')) || [];
    const item = cart.find(item => item.id === productId && item.size === size);
    
    if (item) {
        item.quantity = parseInt(newQty);
        localStorage.setItem('rottenCart', JSON.stringify(cart));
        loadShoppingCart();
        updateCartBadge();
    }
}

/* =========================================
   3. VISTA: PÁGINA DEL CARRITO (Shopping Cart)
   ========================================= */
async function loadShoppingCart() {
    const container = document.getElementById('cart-items-container');
    if (!container) return;

    const cart = JSON.parse(localStorage.getItem('rottenCart')) || [];
    
    if (cart.length === 0) {
        container.innerHTML = '<div class="alert alert-info text-center">Tu carrito está vacío. <br><a href="colections.html" class="btn btn-checkout">Ir a Colecciones</a></div>';
        updateTotals(0);
        return;
    }

    try {
        const response = await fetch(API_URL);
        const allProducts = await response.json();
        
        container.innerHTML = '';
        let grandTotal = 0;

        cart.forEach(cartItem => {
            const productInfo = allProducts.find(p => p.uuid === cartItem.id);
            if (!productInfo) return; 

            const itemTotal = productInfo.price * cartItem.quantity;
            grandTotal += itemTotal;

            container.innerHTML += `
            <div class="d-flex product-item mb-4 pb-3 border-bottom">
                <img src="${productInfo.image}" alt="${productInfo.title}" class="product-image" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                <div class="flex-grow-1 ml-3">
                    <h5 class="mb-1" style="color: #000;">${productInfo.title}</h5>
                    <small class="text-muted" style="color: #333 !important;">Talla: <strong>${cartItem.size}</strong></small>
                    <div class="d-flex align-items-center mt-2">
                        <small class="mr-2" style="color: #333 !important;">Cant:</small>
                        <input type="number" class="form-control form-control-sm" 
                               value="${cartItem.quantity}" min="1" style="width: 60px"
                               onchange="updateQuantity('${cartItem.id}', '${cartItem.size}', this.value)">
                    </div>
                </div>
                <div class="text-right ml-3 product-price">
                    <span class="sale-price" style="color: #5B3A7B; font-weight: bold; font-size: 1.1rem;">$${itemTotal.toFixed(2)}</span>
                </div>
                <button class="btn btn-remove ml-3" style="color: #dc3545;" onclick="removeFromCart('${cartItem.id}', '${cartItem.size}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            `;
        });

        updateTotals(grandTotal);

    } catch (error) {
        console.error("Error cargando carrito:", error);
    }
}

function updateTotals(subtotal) {
    const subtotalEl = document.getElementById('cart-subtotal');
    const totalEl = document.getElementById('cart-total');
    
    // Asumiendo que el envío es fijo o calculado después, aquí ponemos subtotal
    if(subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    if(totalEl) totalEl.textContent = `$${subtotal.toFixed(2)}`;
}