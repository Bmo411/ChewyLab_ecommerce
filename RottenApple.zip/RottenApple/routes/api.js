const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto'); // Para generar UUIDs

const dataPath = path.join(__dirname, '../data/products.json');
const usersPath = path.join(__dirname, '../data/users.json');
const cartPath = path.join(__dirname, '../data/cart.json');

// --- HELPERS ---

const getProducts = () => {
    const data = fs.readFileSync(dataPath);
    return JSON.parse(data);
};

const saveProducts = (products) => {
    fs.writeFileSync(dataPath, JSON.stringify(products, null, 2));
};

const getUsers = () => {
    const data = fs.readFileSync(usersPath);
    return JSON.parse(data);
};

const saveUsers = (users) => {
    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
};

const getCart = () => {
    if (!fs.existsSync(cartPath)) return [];
    const data = fs.readFileSync(cartPath);
    return JSON.parse(data);
};

const saveCart = (cart) => {
    fs.writeFileSync(cartPath, JSON.stringify(cart, null, 2));
};

// --- PRODUCTS API ---

// GET /api/products -> Obtener todos los productos (con filtros opcionales)
router.get('/products', (req, res) => {
    let products = getProducts();
    const { nombre, categoria, precio } = req.query;

    if (nombre) {
        products = products.filter(p => p.title.toLowerCase().includes(nombre.toLowerCase()));
    }
    if (categoria) {
        products = products.filter(p => p.category.toLowerCase() === categoria.toLowerCase());
    }
    if (precio) {
        products = products.filter(p => p.price == precio);
    }

    res.json(products);
});

// GET /api/products/:nombre -> Obtener producto por nombre (o UUID)
router.get('/products/:nombre', (req, res) => {
    const products = getProducts();
    const search = req.params.nombre.toLowerCase();
    const product = products.find(p => p.title.toLowerCase() === search || p.uuid === req.params.nombre);

    if (product) {
        res.json(product);
    } else {
        res.status(404).json({ message: "Producto no encontrado" });
    }
});

// POST /api/products -> Crear producto
router.post('/products', (req, res) => {
    const products = getProducts();
    // Mapeo de claves español -> inglés
    const { nombre, descripcion, precio, categoria, stock, image } = req.body;
    // También aceptamos query params como en el ejemplo de Postman, aunque body es mejor
    const q = req.query;

    const newProduct = {
        uuid: crypto.randomUUID(),
        title: nombre || q.nombre,
        description: descripcion || q.descripcion,
        price: parseFloat(precio || q.precio),
        category: categoria || q.categoria,
        stock: parseInt(stock || q.stock),
        image: image || q.image || "../Media/placeholder.png", // Default image
        oldPrice: null,
        isNew: true
    };

    if (!newProduct.title || !newProduct.price) {
        return res.status(400).json({ message: "Faltan datos requeridos (nombre, precio)" });
    }

    products.push(newProduct);
    saveProducts(products);
    res.status(201).json(newProduct);
});

// PUT /api/products/:nombre -> Actualizar producto
router.put('/products/:nombre', (req, res) => {
    const products = getProducts();
    const search = req.params.nombre.toLowerCase();
    const index = products.findIndex(p => p.title.toLowerCase() === search || p.uuid === req.params.nombre);

    if (index !== -1) {
        const { nombre, descripcion, precio, categoria, stock } = req.body;
        const p = products[index];

        // Actualizar campos si existen
        if (nombre) p.title = nombre;
        if (descripcion) p.description = descripcion;
        if (precio) p.price = parseFloat(precio);
        if (categoria) p.category = categoria;
        if (stock) p.stock = parseInt(stock);

        saveProducts(products);
        res.json(p);
    } else {
        res.status(404).json({ message: "Producto no encontrado" });
    }
});

// DELETE /api/products/:nombre -> Eliminar producto
router.delete('/products/:nombre', (req, res) => {
    let products = getProducts();
    const search = req.params.nombre.toLowerCase();
    const initialLength = products.length;

    products = products.filter(p => p.title.toLowerCase() !== search && p.uuid !== req.params.nombre);

    if (products.length < initialLength) {
        saveProducts(products);
        res.json({ message: "Producto eliminado" });
    } else {
        res.status(404).json({ message: "Producto no encontrado" });
    }
});


// --- USERS API ---

// GET /api/users -> Obtener todos los usuarios
router.get('/users', (req, res) => {
    const users = getUsers();
    res.json(users);
});

// GET /api/users/:email -> Obtener usuario por email
router.get('/users/:email', (req, res) => {
    const users = getUsers();
    const user = users.find(u => u.email === req.params.email);

    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ message: "Usuario no encontrado" });
    }
});

// POST /api/users -> Crear usuario
router.post('/users', (req, res) => {
    const users = getUsers();
    const newUser = req.body;

    if (!newUser.email || !newUser.password || !newUser.name) {
        return res.status(400).json({ message: "Faltan datos requeridos" });
    }

    if (users.find(u => u.email === newUser.email)) {
        return res.status(409).json({ message: "El usuario ya existe" });
    }

    users.push(newUser);
    saveUsers(users);
    res.status(201).json({ message: "Usuario creado", user: newUser });
});

// PUT /api/users/:email -> Actualizar usuario
router.put('/users/:email', (req, res) => {
    const users = getUsers();
    const index = users.findIndex(u => u.email === req.params.email);

    if (index !== -1) {
        const { name, password } = req.body;
        if (name) users[index].name = name;
        if (password) users[index].password = password;

        saveUsers(users);
        res.json(users[index]);
    } else {
        res.status(404).json({ message: "Usuario no encontrado" });
    }
});

// DELETE /api/users/:email -> Eliminar usuario
router.delete('/users/:email', (req, res) => {
    let users = getUsers();
    const initialLength = users.length;
    users = users.filter(u => u.email !== req.params.email);

    if (users.length < initialLength) {
        saveUsers(users);
        res.json({ message: "Usuario eliminado" });
    } else {
        res.status(404).json({ message: "Usuario no encontrado" });
    }
});


// --- CART API ---

// GET /api/cart -> Obtener carrito
router.get('/cart', (req, res) => {
    const cart = getCart();
    res.json(cart);
});

// POST /api/cart/:nombre -> Agregar producto al carrito
router.post('/cart/:nombre', (req, res) => {
    const cart = getCart();
    const products = getProducts();
    const search = req.params.nombre.toLowerCase();

    const product = products.find(p => p.title.toLowerCase() === search || p.uuid === req.params.nombre);

    if (!product) {
        return res.status(404).json({ message: "Producto no encontrado" });
    }

    const cartItemIndex = cart.findIndex(item => item.productUuid === product.uuid);

    if (cartItemIndex !== -1) {
        cart[cartItemIndex].quantity += 1;
    } else {
        cart.push({
            productUuid: product.uuid,
            title: product.title,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }

    saveCart(cart);
    res.json(cart);
});

// PUT /api/cart/:nombre -> Actualizar cantidad (body: { quantity: 5 })
router.put('/cart/:nombre', (req, res) => {
    const cart = getCart();
    const search = req.params.nombre.toLowerCase();
    const index = cart.findIndex(item => item.title.toLowerCase() === search || item.productUuid === req.params.nombre);

    if (index !== -1) {
        const { quantity } = req.body;
        if (quantity !== undefined) {
            cart[index].quantity = parseInt(quantity);
            if (cart[index].quantity <= 0) {
                cart.splice(index, 1);
            }
        }
        saveCart(cart);
        res.json(cart);
    } else {
        res.status(404).json({ message: "Producto no encontrado en el carrito" });
    }
});

// DELETE /api/cart/:nombre -> Eliminar del carrito
router.delete('/cart/:nombre', (req, res) => {
    let cart = getCart();
    const search = req.params.nombre.toLowerCase();
    const initialLength = cart.length;

    cart = cart.filter(item => item.title.toLowerCase() !== search && item.productUuid !== req.params.nombre);

    if (cart.length < initialLength) {
        saveCart(cart);
        res.json(cart);
    } else {
        res.status(404).json({ message: "Producto no encontrado en el carrito" });
    }
});

module.exports = router;